Select p.*, r.*
from "<<featuretype>>party" as p join "<<featuretype>>right_restr_resp" as r on p.party_id=r.party_id